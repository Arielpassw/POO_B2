public class Main_login {
    public static void main(String[] args) {
   new Login();

        }


}